package com.dol.telegramtest;

public class app {

	public static void main(String[] args) {
				

			String apiToken = "909291353:AAGfS9867WutcaHYlHzF9fmBlPN_r5IXumg";   //apiToken of your bot created by botFather
			String chatId = "934650256";   // you can get this from https://api.telegram.org/bot[apiToken]/getupdates
			String message = "Guys, let's party tonight!";  // TODO: Specify the content of your message
			
			 TelegramBotSender.sendToTelegram(apiToken,chatId, message);
			 
			// "934650256" is what you got from 
		/*
			String groupName = "test_group";    // TODO: Specify the name of the group
			String number = "+4917693581956";  // Specify the recipient's number (NOT the gateway number) here.
		    
			try {
				// TelegramGroupSender.sendGroupMessage(groupName, message);
				TelegramSender.sendMessage(number, message);
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		*/	
	}

}
